const audio = document.getElementById("audio");
const trackGrid = document.getElementById("trackGrid");
const recentList = document.getElementById("recentList");
const libraryList = document.getElementById("libraryList");
const favoriteList = document.getElementById("favoriteList");
const nowTitle = document.getElementById("nowTitle");
const nowArtist = document.getElementById("nowArtist");
const nowArt = document.getElementById("nowArt");
const favoriteBtn = document.getElementById("favoriteBtn");
const playBtn = document.getElementById("playBtn");
const progress = document.getElementById("progress");
const currentTimeEl = document.getElementById("currentTime");
const durationEl = document.getElementById("duration");
const volume = document.getElementById("volume");
const muteBtn = document.getElementById("muteBtn");
const shuffleBtn = document.getElementById("shuffleBtn");
const repeatBtn = document.getElementById("repeatBtn");
const autoplayBtn = document.getElementById("autoplayBtn");
const toast = document.getElementById("toast");

const demoTracks = [
  {title:"Midnight Drive", artist:"Nova Lane", src:"assets/audio/midnight-drive.wav", art:"assets/art/aurora.svg", duration:"0:12"},
  {title:"Neon Skies", artist:"The Daylights", src:"assets/audio/neon-skies.wav", art:"assets/art/neon.svg", duration:"0:12"},
  {title:"Golden Hour", artist:"Mira Sol", src:"assets/audio/golden-hour.wav", art:"assets/art/golden.svg", duration:"0:12"},
  {title:"Ocean Eyes", artist:"Luna Ray", src:"assets/audio/ocean-eyes.wav", art:"assets/art/ocean.svg", duration:"0:12"}
];

let tracks = [...demoTracks];
let currentIndex = 0;
let isShuffle = false;
let isRepeat = false;
let isAutoplay = false;
let recent = [];
let favorites = new Set();
let userVolume = .8;

try {
  const savedFav = JSON.parse(localStorage.getItem("pulseFavorites") || "[]");
  favorites = new Set(savedFav);
  recent = JSON.parse(localStorage.getItem("pulseRecent") || "[]");
} catch {}

function saveState(){
  localStorage.setItem("pulseFavorites", JSON.stringify([...favorites]));
  localStorage.setItem("pulseRecent", JSON.stringify(recent));
}
function showToast(msg){
  toast.textContent = msg; toast.classList.add("show");
  clearTimeout(showToast.t); showToast.t = setTimeout(()=>toast.classList.remove("show"),1800);
}
function fmt(sec){
  if(!Number.isFinite(sec)) return "0:00";
  const m = Math.floor(sec/60), s = Math.floor(sec%60);
  return `${m}:${String(s).padStart(2,"0")}`;
}
function current(){ return tracks[currentIndex]; }

function loadTrack(index, auto=false){
  if(!tracks.length) return;
  currentIndex = (index + tracks.length) % tracks.length;
  const t = current();
  audio.src = t.src;
  nowTitle.textContent = t.title;
  nowArtist.textContent = t.artist;
  nowArt.src = t.art;
  favoriteBtn.classList.toggle("liked", favorites.has(t.src));
  favoriteBtn.textContent = favorites.has(t.src) ? "♥" : "♡";
  progress.value = 0; currentTimeEl.textContent = "0:00";
  durationEl.textContent = t.duration || "0:00";
  if(auto) playAudio();
  renderAll();
}
async function playAudio(){
  try { await audio.play(); playBtn.textContent = "❚❚"; }
  catch { showToast("Add or select an audio file to play."); }
}
function pauseAudio(){ audio.pause(); playBtn.textContent = "▶"; }
function togglePlay(){ audio.paused ? playAudio() : pauseAudio(); }
function next(){
  let nextIndex;
  if(isShuffle && tracks.length > 1){
    do nextIndex = Math.floor(Math.random()*tracks.length); while(nextIndex === currentIndex);
  } else nextIndex = currentIndex + 1;
  loadTrack(nextIndex, true);
}
function previous(){
  if(audio.currentTime > 3){ audio.currentTime = 0; return; }
  loadTrack(currentIndex - 1, true);
}
function toggleFavorite(){
  const key = current().src;
  favorites.has(key) ? favorites.delete(key) : favorites.add(key);
  saveState(); updateFavoriteUI(); renderAll();
  showToast(favorites.has(key) ? "Added to favorites ♥" : "Removed from favorites");
}
function updateFavoriteUI(){
  const liked = favorites.has(current().src);
  favoriteBtn.classList.toggle("liked", liked);
  favoriteBtn.textContent = liked ? "♥" : "♡";
}
function trackCard(t, i){
  return `<article class="track-card" data-index="${i}">
    <img class="cover" src="${t.art}" alt="${t.title} artwork">
    <div class="track-info"><div class="track-title">${t.title}</div><div class="track-artist">${t.artist}</div>
    <div class="track-meta"><span class="track-duration">${t.duration || "—"}</span><button class="card-play" data-play="${i}">▶</button></div></div>
  </article>`;
}
function row(t, i, remove=false){
  return `<div class="recent-row" data-index="${i}">
    <img class="small-cover" src="${t.art}" alt="">
    <div><div class="row-title">${t.title}</div><div class="row-artist">${t.artist}</div></div>
    <span class="row-time">${t.duration || "—"}</span>
    <div class="row-actions"><button data-play="${i}" title="Play">▶</button>${remove?"":`<button data-fav="${i}" title="Favorite">${favorites.has(t.src)?"♥":"♡"}</button>`}</div>
  </div>`;
}
function renderAll(){
  const q = document.getElementById("searchInput").value.toLowerCase().trim();
  const filtered = tracks.map((t,i)=>({t,i})).filter(x => !q || `${x.t.title} ${x.t.artist}`.toLowerCase().includes(q));
  trackGrid.innerHTML = filtered.map(x=>trackCard(x.t,x.i)).join("") || `<div style="color:var(--muted);font-size:12px;padding:20px">No matching songs.</div>`;
  const recTracks = recent.map(src=>tracks.find(t=>t.src===src)).filter(Boolean).slice(0,5);
  recentList.innerHTML = recTracks.length ? recTracks.map(t=>row(t,tracks.indexOf(t))).join("") : `<div style="padding:22px;color:var(--muted);font-size:11px">Your recently played songs will appear here.</div>`;
  libraryList.innerHTML = tracks.map((t,i)=>row(t,i)).join("");
  const favs = tracks.filter(t=>favorites.has(t.src));
  favoriteList.innerHTML = favs.length ? favs.map(t=>row(t,tracks.indexOf(t))).join("") : `<div style="padding:30px;text-align:center;color:var(--muted);font-size:12px">No favorite songs yet. Tap ♡ while a song is playing.</div>`;
}
function addFiles(files){
  [...files].forEach(file=>{
    const url = URL.createObjectURL(file);
    tracks.push({title:file.name.replace(/\.[^/.]+$/,""), artist:"Local file", src:url, art:"assets/art/neon.svg", duration:"—", local:true});
  });
  renderAll();
  if(tracks.length && currentIndex === 0 && audio.src === "") loadTrack(tracks.length-files.length);
  showToast(`${files.length} song${files.length>1?"s":""} added`);
}

document.getElementById("fileInput").addEventListener("change", e => addFiles(e.target.files));
playBtn.addEventListener("click", togglePlay);
document.getElementById("prevBtn").addEventListener("click", previous);
document.getElementById("nextBtn").addEventListener("click", next);
favoriteBtn.addEventListener("click", toggleFavorite);
heroPlay.addEventListener("click", ()=>{ if(audio.src === "") loadTrack(0,true); else playAudio(); });
document.getElementById("showAll").addEventListener("click", ()=>showView("library"));

progress.addEventListener("input", ()=>{ if(audio.duration) audio.currentTime = (progress.value/100)*audio.duration; });
volume.addEventListener("input", ()=>{ userVolume = Number(volume.value); audio.volume=userVolume; audio.muted=false; muteBtn.textContent="🔊"; });
muteBtn.addEventListener("click", ()=>{ audio.muted=!audio.muted; muteBtn.textContent=audio.muted?"🔇":"🔊"; });
shuffleBtn.addEventListener("click", ()=>{ isShuffle=!isShuffle; shuffleBtn.classList.toggle("active",isShuffle); showToast(isShuffle?"Shuffle on":"Shuffle off"); });
repeatBtn.addEventListener("click", ()=>{ isRepeat=!isRepeat; repeatBtn.classList.toggle("active",isRepeat); showToast(isRepeat?"Repeat on":"Repeat off"); });
autoplayBtn.addEventListener("click", ()=>{ isAutoplay=!isAutoplay; autoplayBtn.classList.toggle("active",isAutoplay); showToast(isAutoplay?"Autoplay on":"Autoplay off"); });

audio.volume=userVolume;
audio.addEventListener("loadedmetadata",()=>{
  durationEl.textContent=fmt(audio.duration);
  if(current()) current().duration=fmt(audio.duration);
  renderAll();
});
audio.addEventListener("timeupdate",()=>{
  if(audio.duration){
    progress.value=(audio.currentTime/audio.duration)*100;
    currentTimeEl.textContent=fmt(audio.currentTime);
    durationEl.textContent=fmt(audio.duration);
  }
});
audio.addEventListener("play",()=>playBtn.textContent="❚❚");
audio.addEventListener("pause",()=>playBtn.textContent="▶");
audio.addEventListener("ended",()=>{
  if(isRepeat){ audio.currentTime=0; playAudio(); }
  else if(isAutoplay || isShuffle) next();
  else pauseAudio();
});
audio.addEventListener("error",()=>showToast("This audio file could not be played."));
audio.addEventListener("play",()=>{
  const src=current()?.src;
  if(src){
    recent=[src,...recent.filter(x=>x!==src)].slice(0,8); saveState(); renderAll();
  }
});

document.getElementById("searchInput").addEventListener("input",renderAll);
document.getElementById("themeToggle").addEventListener("click",()=>{
  document.body.classList.toggle("dark");
  localStorage.setItem("pulseTheme",document.body.classList.contains("dark")?"dark":"light");
});
if(localStorage.getItem("pulseTheme")==="dark") document.body.classList.add("dark");

function showView(view){
  document.querySelectorAll(".content").forEach(x=>x.classList.add("hidden"));
  document.getElementById(view+"View").classList.remove("hidden");
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.view===view));
  document.querySelector(".sidebar").classList.remove("open");
}
document.querySelectorAll(".nav-item").forEach(btn=>btn.addEventListener("click",()=>showView(btn.dataset.view)));
document.querySelectorAll(".playlist-link").forEach(btn=>btn.addEventListener("click",()=>{
  if(btn.dataset.playlist==="favorites") showView("favorites"); else showView("library");
}));
document.getElementById("mobileMenu").addEventListener("click",()=>document.querySelector(".sidebar").classList.toggle("open"));

document.addEventListener("click", e=>{
  const play = e.target.closest("[data-play]");
  const fav = e.target.closest("[data-fav]");
  if(play){ e.stopPropagation(); loadTrack(Number(play.dataset.play),true); }
  if(fav){ e.stopPropagation(); currentIndex=Number(fav.dataset.fav); toggleFavorite(); }
  const card=e.target.closest(".track-card");
  if(card && !e.target.closest("button")) loadTrack(Number(card.dataset.index),true);
  const rr=e.target.closest(".recent-row,.library-row");
  if(rr && !e.target.closest("button")) loadTrack(Number(rr.dataset.index),true);
});

loadTrack(0,false);
renderAll();

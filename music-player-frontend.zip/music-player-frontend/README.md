# Pulse Music Player — Frontend

A complete responsive music player made with plain HTML, CSS and JavaScript. It works directly with VS Code Live Server.

## Run it

1. Open the `music-player-frontend` folder in VS Code.
2. Install the **Live Server** extension if you do not already have it.
3. Right-click `index.html`.
4. Choose **Open with Live Server**.
5. The player opens in your browser.

## Included features

- Modern responsive music-player UI
- Play / Pause
- Previous / Next
- Progress bar with seeking
- Current time and duration
- Volume slider and mute
- Shuffle
- Repeat
- Autoplay
- Favorites stored in localStorage
- Recently played list stored in localStorage
- Search songs/artists
- Library and Favorites views
- Dark/light theme
- Responsive mobile sidebar
- Add local audio files with the "Add music" button
- Demo WAV tracks included so the interface works immediately

## Add your own music

Click **Add music** and select MP3, WAV, OGG, M4A, or another browser-supported audio file. The files are loaded locally in your browser; no backend is required.

## Folder structure

music-player-frontend/
├── index.html
├── style.css
├── script.js
├── README.md
└── assets/
    ├── audio/
    │   ├── midnight-drive.wav
    │   ├── neon-skies.wav
    │   ├── golden-hour.wav
    │   └── ocean-eyes.wav
    └── art/
        ├── aurora.svg
        ├── neon.svg
        ├── golden.svg
        └── ocean.svg

No npm install or build command is required.
